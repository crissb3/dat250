package com.example.assignmentB;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AssignmentBApplicationTests {

	@Test
	void contextLoads() {
	}

}
