package com.example.assignmentB;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AssignmentBApplication {

	public static void main(String[] args) {
		SpringApplication.run(AssignmentBApplication.class, args);
	}

}
